import os
import requests
import random

DEV_TO_API_KEY = os.getenv("DEV_TO_API_KEY")
LANDING_PAGE_URL = "https://nextlevelwasmer.app"

TITLES = [
    "How to Build a Zero-Cost Traffic Rotator Funnel in 2026",
    "Scaling Affiliate Conversions with Automated Autoresponder Loops",
    "Step-by-Step Guide: Setting Up High-Converting Lead Capture Funnels"
]

CONTENT = """
# Automated Traffic & Lead Generation Mechanics

In modern affiliate marketing, sending raw visitor hits directly to affiliate links leads to account bans and lost conversions. The highest converting approach involves a 3-stage loop:

1. **Targeted Discovery:** Capturing high-intent search traffic.
2. **List Building:** Securing the subscriber in an automated autoresponder engine.
3. **Instant Monetization:** Immediate redirect to front-end offers followed by automated drip sequences.

### Deploy the Free Infrastructure
You can access the complete multi-tier resource directory, complete with free rotator templates and automated capture forms, directly from our resource portal below:

👉 **[Access the Complete Funnel & Free Blueprints Here]({landing_url})**
"""

def publish_devto():
    if not DEV_TO_API_KEY:
        print("DEV_TO_API_KEY not set.")
        return
    url = "https://dev.to/api/articles"
    title = random.choice(TITLES)
    body = CONTENT.format(landing_url=LANDING_PAGE_URL)

    payload = {
        "article": {
            "title": title,
            "published": True,
            "body_markdown": body,
            "tags": ["affiliate", "marketing", "automation", "webdev"]
        }
    }
    headers = {
        "api-key": DEV_TO_API_KEY,
        "Content-Type": "application/json"
    }

    res = requests.post(url, json=payload, headers=headers)
    if res.status_code == 201:
        print(f"Successfully published: {title}")
    else:
        print(f"Failed to publish: {res.text}")

if __name__ == "__main__":
    publish_devto()
